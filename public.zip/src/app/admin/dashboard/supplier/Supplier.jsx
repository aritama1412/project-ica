import React from "react";

export default function Supplier() {
  return (
    <div className="p-4 border border-gray-200">
      <h1>Supplier</h1>
      <div className="px-4 border border-gray-200">data item</div>
    </div>
  );
}
