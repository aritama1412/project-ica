import React from "react";

export default function CreateStockProduct() {
  return <div>create page</div>;
}
