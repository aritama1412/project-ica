"use client";
import LoginPage from "./(auth)/login/page";

const AdminPage = () => {
  return <LoginPage></LoginPage>;
};

export default AdminPage;
